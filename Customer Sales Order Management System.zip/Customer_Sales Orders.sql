CREATE TABLE customers (
    customer_id INT PRIMARY KEY,
    name        VARCHAR(50),
    city        VARCHAR(50),
    country     VARCHAR(50)
);
INSERT INTO customers (customer_id, name, city, country) VALUES
(1,'Ali Khan','Lahore','Pakistan'),
(2,'Sara Ijaz','Karachi','Pakistan'),
(3,'John Doe','New York','USA'),
(4,'Ayesha','Islamabad','Pakistan'),
(5,'Ahmed','Dubai','UAE');
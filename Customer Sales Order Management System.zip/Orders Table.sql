CREATE TABLE orders (
    order_id    INT PRIMARY KEY,
    customer_id INT,
    product     VARCHAR(50),
    quantity    INT,
    price       DECIMAL(10,2),
    order_date  DATE,
    CONSTRAINT fk_cust
      FOREIGN KEY (customer_id) REFERENCES customers(customer_id)
);

INSERT INTO orders (order_id, customer_id, product, quantity, price, order_date) VALUES
(101,1,'Laptop',       1, 80000,'2024-07-10'),
(102,3,'Headphones',   2,  5000,'2024-07-11'),
(103,2,'Mobile Phone', 1, 60000,'2024-07-12'),
(104,1,'Mouse',        3,  1500,'2024-07-13'),
(105,5,'Tablet',       2, 40000,'2024-07-14'),
(106,4,'Laptop',       1, 75000,'2024-07-15');
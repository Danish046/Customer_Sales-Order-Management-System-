-- Create a view for customer purchases
CREATE VIEW customer_purchases AS
SELECT c.name, c.city, o.product, o.quantity, o.price,
       (o.quantity * o.price) AS total_amount, o.order_date
FROM orders o
JOIN customers c ON o.customer_id = c.customer_id;
DELIMITER $$

CREATE FUNCTION calculate_discount(total DECIMAL(10,2))
RETURNS DECIMAL(10,2)
DETERMINISTIC
BEGIN
    DECLARE discount DECIMAL(10,2);
    IF total > 50000 THEN
        SET discount = total * 0.10; -- 10% discount
    ELSE
        SET discount = 0;
    END IF;
    RETURN discount;
END $$

DELIMITER ;